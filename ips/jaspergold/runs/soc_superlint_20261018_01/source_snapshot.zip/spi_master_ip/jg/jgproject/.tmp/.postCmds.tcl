exit -force
